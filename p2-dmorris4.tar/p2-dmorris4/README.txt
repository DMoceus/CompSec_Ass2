David Morris

dmorris4@binghamton.edu

Tested on remote.cs.binghamton.edu

The thing doesn't work. It compiles and runs, and most definitely pipes SOMETHING into the encrypter, however I am currently at the Binghamton Hackathon and have no more time to work on this project. (Sad Face Here)

Also, I changed the filetypes from .cc to .cpp, so please use G++ for the compiler.